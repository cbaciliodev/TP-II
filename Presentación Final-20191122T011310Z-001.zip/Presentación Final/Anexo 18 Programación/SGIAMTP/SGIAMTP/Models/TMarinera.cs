﻿using System;
using System.Collections.Generic;

namespace SGIAMTP.Models
{
    public partial class TMarinera
    {
        public int PkImCod { get; set; }
        public string VmNombre { get; set; }
    }
}
